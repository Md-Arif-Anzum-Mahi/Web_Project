package com.mahi.arif.pages;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.github.dockerjava.api.model.Driver;
import com.mahi.arif.basedrives.BaseDriver;
import com.mahi.arif.basedrives.PageDriver;
import com.mahi.arif.utilies.ExcelUtilies;
import com.mahi.arif.utilies.GetScreenShot;

public class WriterClick extends BaseDriver {
	ExtentTest test;
	//ExcelUtilies excelData = new ExcelUtilies();
	
	public  WriterClick(ExtentTest test) {
		
		PageFactory.initElements(PageDriver.getCurrentDriver(),this);
		this.test= test;
	}
	
	@FindBy(xpath="//span[@class='menu-label-level-0'][contains(text(),'লেখক')]")
	WebElement writer;
	//@FindBy(xpath="//body/div[1]/div[3]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[3]/nav[1]/ul[1]/li[2]/a[1]")
	//WebElement pageDown;
	@FindBy(xpath="//a[normalize-space()='2']")
	WebElement next_page;
	@FindBy(xpath="//a[@href='/cat/books/author/']")
	WebElement pre_page;
	
	
	
	 
	
	public void login() throws InterruptedException, IOException {
		
				try {
					test.info("Click on the Writer");
					if(writer.isDisplayed()) {
						writer.click();
						Thread.sleep(2000);	
						
					}
				
					try {
						test.info("NextPage on the Writer");
						if(next_page.isDisplayed()) {
							next_page.click();
							Thread.sleep(2000);	
							//search_name.sendKeys("mahi.");
							
						}
						try {
							test.info("Back the Writer");
							if(pre_page.isDisplayed()) {
								pre_page.click();
								Thread.sleep(2000);	
								//search_name.sendKeys("mahi.");
								
							}
						}
							catch (Exception e) {
								System.out.println("Sorry1");
							}
						
					} catch (Exception e) {
						System.out.println("Sorry2");
					}
						
					} 
			
					catch (Exception e) {
						System.out.println("Sorry3");
					}
	}
}