package com.mahi.arif.pages;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.github.dockerjava.api.model.Driver;
import com.mahi.arif.basedrives.BaseDriver;
import com.mahi.arif.basedrives.PageDriver;
import com.mahi.arif.utilies.ExcelUtilies;
import com.mahi.arif.utilies.GetScreenShot;

public class SearchWriter extends BaseDriver {
	ExtentTest test;
	//ExcelUtilies excelData = new ExcelUtilies();
	
	public  SearchWriter(ExtentTest test) {
		
		PageFactory.initElements(PageDriver.getCurrentDriver(),this);
		this.test= test;
	}
	
	
	@FindBy(xpath="//input[@id='cat_search']")
	WebElement search_name;
	@FindBy(xpath="//button[@class='btn btn-default']")
	WebElement click_search;
	@FindBy(xpath="//h3[contains(text(),'শাঈখ মাহফুজ')]")
	WebElement click_name; 
	
	@FindBy(xpath="//body/div[contains(@class,'body-wrapper')]/div[contains(@class,'wd-content')]/div[@id='template-wrapper']/div[@id='main-module-container']/div[@id='container']/div[@id='content']/div[@id='main']/div[@id='container-main']/div[contains(@class,'main-content')]/article[@id='post-23109']/div[contains(@class,'entry-content-post')]/div[contains(@class,'cls_results')]/div[contains(@class,'wdm_resultContainer')]/div[contains(@class,'wdm_results woocommerce')]/div[contains(@class,'results-by-facets')]/ul[contains(@class,'products')]/li[2]/div[1]/div[1]/a[1]")
	WebElement click_bookname;
	
	public void login() throws InterruptedException, IOException {
		
		try {
			test.info("Search on the Writer");
			if(search_name.isDisplayed()) {
				search_name.click();
				Thread.sleep(2000);	
				search_name.sendKeys("শাঈখ মাহফুজ");
				
			}
			
			try {
				test.info("Click the search button");
				if(click_search.isDisplayed()) {
					click_search.click();
					Thread.sleep(2000);
				}
				
				try {
					test.info("Click the name");
					if(click_name.isDisplayed()) {
						click_name.click();
						Thread.sleep(2000);
					
					}
					
					try {
						test.info("Click the name");
						if(click_bookname.isDisplayed()) {
							click_bookname.click();
							Thread.sleep(2000);
						
						}
						
					} catch (Exception e) {
						System.out.println("Sorry4");
					}
					
					
				} catch (Exception e) {
					System.out.println("Sorry5");
				}
			} catch (Exception e) {
				System.out.println("Sorry6");
			}
			
		}
			catch (Exception e) {
				System.out.println("Sorry7");
			}
		
		
		
		
		
	
	}
}