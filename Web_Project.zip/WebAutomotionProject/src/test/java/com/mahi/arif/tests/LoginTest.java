package com.mahi.arif.tests;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.WindowType;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.github.dockerjava.api.model.Driver;
import com.mahi.arif.basedrives.BaseDriver;
import com.mahi.arif.basedrives.PageDriver;
import com.mahi.arif.pages.FramHandel;
import com.mahi.arif.pages.SearchWriter;
import com.mahi.arif.pages.WriterClick;
import com.mahi.arif.utilies.ExtentFactory;

public class LoginTest extends BaseDriver {
	
	ExtentReports report;
	ExtentTest parentTest;
	ExtentTest childTest;
	
	
	@BeforeClass
	public void start() throws InterruptedException {
		
		PageDriver.getCurrentDriver().get(url);
		Thread.sleep(2000);
		report = ExtentFactory.getInstance();
		parentTest= report.createTest("<p style=\"color:#FF6000; font-size:20px\"><b>ORANGE HRM LOGIN</b></p>").assignAuthor("QA TEAM").assignDevice("Windows");
		
	}
public List<String>windowhandle (){
		
		Set<String>windowhandles = driver.getWindowHandles();
		List<String>windowlist = new ArrayList<String>(windowhandles);
		
		return windowlist;
		
	}
	
	@Test
	public void logintest() throws InterruptedException, IOException {
		childTest = parentTest.createNode("<p style=\"color:#3F96E7; font-size:20px\"><b>LOGIN</b></p>");
		WriterClick LT = new WriterClick(childTest);
		SearchWriter SW = new SearchWriter(childTest);
		FramHandel FH = new FramHandel(childTest);
		FH.login();
		LT.login();
		SW.login();
		
		
	}
	@AfterClass
	public void report() {
		
		report.flush();
	}

}
