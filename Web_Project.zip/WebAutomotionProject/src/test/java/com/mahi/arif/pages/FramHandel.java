package com.mahi.arif.pages;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.github.dockerjava.api.model.Driver;
import com.mahi.arif.basedrives.BaseDriver;
import com.mahi.arif.basedrives.PageDriver;
import com.mahi.arif.utilies.ExcelUtilies;
import com.mahi.arif.utilies.GetScreenShot;

public class FramHandel extends BaseDriver {
	ExtentTest test;
	//ExcelUtilies excelData = new ExcelUtilies();
	
	public  FramHandel(ExtentTest test) {
		
		PageFactory.initElements(PageDriver.getCurrentDriver(),this);
		this.test= test;
	}
	
	@FindBy(xpath="//body/div[1]/div[3]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[2]/form[1]/div[2]/button[2]")
	WebElement order;
	
	
	
	
	 
	
	public void login() throws InterruptedException, IOException {
		
				try {
					test.info("Click for Order");
					if(order.isDisplayed()) {
						order.click();
						Thread.sleep(4000);	
						
					}
				}
				
					catch (Exception e) {
						System.out.println("Mahi sorry");
					}
	}
	
}

